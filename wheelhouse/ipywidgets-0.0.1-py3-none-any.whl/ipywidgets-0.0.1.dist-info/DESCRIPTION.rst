IPython Static Widgets


