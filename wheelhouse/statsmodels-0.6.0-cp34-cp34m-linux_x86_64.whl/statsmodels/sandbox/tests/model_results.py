"""
This should be merged into statsmodels/tests/model_results.py when things
move out of the sandbox.
"""
import numpy as np





