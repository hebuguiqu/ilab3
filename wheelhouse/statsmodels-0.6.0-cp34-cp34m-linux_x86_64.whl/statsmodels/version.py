
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.6.0'
version = '0.6.0'
full_version = '0.6.0'
git_revision = 'd946eb0fbfa37ff9bbb71c39ef411d80a08b3ca2'
release = True

if not release:
    version = full_version