
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.6.0'
version = '0.6.0'
full_version = '0.6.0.dev-ab12fc2'
git_revision = 'ab12fc206a4a63774b659cd31d8076359758fd3f'
release = False

if not release:
    version = full_version