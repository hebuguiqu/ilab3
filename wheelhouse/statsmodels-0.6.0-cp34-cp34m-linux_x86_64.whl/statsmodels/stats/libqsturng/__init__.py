
from .qsturng_ import psturng, qsturng, p_keys, v_keys

from numpy.testing import Tester
test = Tester().test
