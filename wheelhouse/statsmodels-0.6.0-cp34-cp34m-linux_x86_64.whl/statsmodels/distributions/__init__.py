from .empirical_distribution import ECDF, monotone_fn_inverter, StepFunction

from statsmodels import NoseWrapper as Tester
test = Tester().test
