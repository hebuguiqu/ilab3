from .tools import add_constant, categorical

from statsmodels import NoseWrapper as Tester
test = Tester().test
