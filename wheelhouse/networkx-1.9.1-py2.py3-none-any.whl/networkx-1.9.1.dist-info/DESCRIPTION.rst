NetworkX is a Python package for the creation, manipulation, and
study of the structure, dynamics, and functions of complex networks.



