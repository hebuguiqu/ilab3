from .singularities import singularities
