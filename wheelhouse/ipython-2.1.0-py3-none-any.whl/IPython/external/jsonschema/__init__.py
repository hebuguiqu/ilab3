try:
    from jsonschema import *
except ImportError :
    from ._jsonschema import *
